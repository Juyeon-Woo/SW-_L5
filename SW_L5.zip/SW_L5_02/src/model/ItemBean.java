package model;

import java.sql.*;
import javax.servlet.*;

public class ItemBean {

	private String code;
	private String company;

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getCompany() {
		return company;
	}

	public void setCompany(String company) {
		this.company = company;
	}

	public void selectItem(String code) throws ServletException {
		Connection conn = null;
		Statement stmt = null;
		ResultSet rs = null;

		try {
			Class.forName("oracle.jdbc.OracleDriver");
			conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "system", "hrdkorea");
			if (conn == null)
				System.out.println("jywoo########## conn fail");
			else
				System.out.println("jywoo########## conn success");

			stmt = conn.createStatement();
			rs = stmt.executeQuery("select * from item where code='" + code +"'");
			System.out.println("jywoo########## 01");

			if (rs.next()) {
				System.out.println("jywoo########## 02" + rs.getString("company"));
				this.code = rs.getString("code");
				this.company = rs.getString("company");
			}
			else{
				this.code = code;
				this.company ="등록되지 않은 제품입니다!!";
			}
		
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (Exception e) {
			throw new ServletException(e);
		} finally {
			try {
				rs.close();
				stmt.close();
				conn.close();
			} catch (Exception e) {
			}
		}
	}
}
