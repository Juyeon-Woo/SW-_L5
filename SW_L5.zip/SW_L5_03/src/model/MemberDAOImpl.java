package model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class MemberDAOImpl extends MemberDAO{
	private static MemberDAOImpl instance=new MemberDAOImpl();
	public static MemberDAOImpl getInstance(){
		return instance;
	}
	private MemberDAOImpl() {}
	
	@Override
	public int create(MemberVO vo){
		Connection conn=null;
		PreparedStatement pstmt = null;
		int rs = 0;
		String sql = null;
		try {
			conn = getConnection();
			sql = "insert into custom_01 values (?,?,?,?,?)";
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, vo.getP_id());
			pstmt.setString(2, vo.getP_pw());
			pstmt.setString(3, vo.getC_name());
			pstmt.setString(4, vo.getC_email());
			pstmt.setString(5, vo.getC_tel());
			rs = pstmt.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			closeDBResources(pstmt, conn);
		}
		return rs;
	}
@Override
public ArrayList<MemberVO> readList(){
	Connection conn=null;
	PreparedStatement pstmt = null;
	ResultSet rs = null;
	String sql = null;
	ArrayList<MemberVO> mb = new ArrayList<MemberVO>();
	try {
		conn = getConnection();
		sql = "select * from custom_01";
		pstmt = conn.prepareStatement(sql);
		if(vo.getP_id()!=null) {
			pstmt.setString(1, vo.getP_id());
		} else
			pstmt.setString(1, " ");
		rs = pstmt.executeQuery();
		if(rs.next()) {
			mb.setP_id(rs.getString(1));
			mb.setP_pw(rs.getString(2));
			mb.setC_name(rs.getString(3));
			mb.setC_email(rs.getString(4));
			mb.setC_tel(rs.getString(5));
		}
	} catch (Exception e) {
		e.printStackTrace();
	} finally {
		closeDBResources(rs, pstmt, conn);
	}
	return mb;
}
}